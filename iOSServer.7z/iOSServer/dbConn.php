<?php

$serverName = "85.195.100.106, 10433";
$connectionInfo = array(
    "Database" => "SANSFA_TwentyThree",
    "LoginTimeout" => 30,
    "UID" => "sa",
    "PWD" => "kuB7ucRiy--hixlw"
);

/* Connect using Windows Authentication. */
$conn = sqlsrv_connect($serverName, $connectionInfo);
$NeedRollBack=false;
if ($conn === false) {
    echo "Unable to connect.</br>";
    die(print_r(sqlsrv_errors(), true));
}
?>

